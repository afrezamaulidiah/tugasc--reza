﻿using MySql.Data.MySqlClient;
using System;
using System.Data;
using System.Windows.Forms;

internal class DbPerpustakaan
{
    private static string connectionString = "Server=localhost;Database=pelanggan;User ID=root;Password=;";


    public static DataTable TampilkanDataBuku()
    {
        using (MySqlConnection conn = DapatkanKoneksi())
        {
            conn.Open();
            string sql = "SELECT * FROM buku";
            using (MySqlCommand cmd = new MySqlCommand(sql, conn))
            {
                try
                {
                    DataTable dataTable = new DataTable();
                    MySqlDataAdapter adapter = new MySqlDataAdapter(cmd);
                    adapter.Fill(dataTable);
                    return dataTable;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return null;
                }
            }
        }
    }

    public static void TambahBuku(Buku buku)
    {
        using (MySqlConnection conn = DapatkanKoneksi())
        {
            conn.Open();
            string sql = "INSERT INTO buku (judul, pengarang, tahun_terbit, penerbit) VALUES (@Judul, @Pengarang, @TahunTerbit, @Penerbit)";
            using (MySqlCommand cmd = new MySqlCommand(sql, conn))
            {
                cmd.CommandType = CommandType.Text;
                cmd.Parameters.Add("@Judul", MySqlDbType.VarChar).Value = buku.Judul;
                cmd.Parameters.Add("@Pengarang", MySqlDbType.VarChar).Value = buku.Pengarang;
                cmd.Parameters.Add("@TahunTerbit", MySqlDbType.Int32).Value = buku.TahunTerbit;
                cmd.Parameters.Add("@Penerbit", MySqlDbType.VarChar).Value = buku.Penerbit;

                try
                {
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Data Berhasil Ditambahkan", "Informasi", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Isi Data Tersebut \n" + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
    }

    private static MySqlConnection DapatkanKoneksi()
    {
        return new MySqlConnection(connectionString);
    }
}
