﻿namespace AplikasiPerpustakaan
{
    partial class FormUtama
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridViewBuku = new System.Windows.Forms.DataGridView();
            this.lblJudul = new System.Windows.Forms.Label();
            this.lblPengarang = new System.Windows.Forms.Label();
            this.lblTahunTerbit = new System.Windows.Forms.Label();
            this.lblPenerbit = new System.Windows.Forms.Label();
            this.txtJudul = new System.Windows.Forms.TextBox();
            this.txtPengarang = new System.Windows.Forms.TextBox();
            this.txtTahunTerbit = new System.Windows.Forms.TextBox();
            this.txtPenerbit = new System.Windows.Forms.TextBox();
            this.btnTambahBuku = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewBuku)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridViewBuku
            // 
            this.dataGridViewBuku.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewBuku.Location = new System.Drawing.Point(27, 211);
            this.dataGridViewBuku.Name = "dataGridViewBuku";
            this.dataGridViewBuku.Size = new System.Drawing.Size(386, 149);
            this.dataGridViewBuku.TabIndex = 0;
            // 
            // lblJudul
            // 
            this.lblJudul.AutoSize = true;
            this.lblJudul.Location = new System.Drawing.Point(24, 25);
            this.lblJudul.Name = "lblJudul";
            this.lblJudul.Size = new System.Drawing.Size(35, 13);
            this.lblJudul.TabIndex = 1;
            this.lblJudul.Text = "Judul:";
            // 
            // lblPengarang
            // 
            this.lblPengarang.AutoSize = true;
            this.lblPengarang.Location = new System.Drawing.Point(24, 58);
            this.lblPengarang.Name = "lblPengarang";
            this.lblPengarang.Size = new System.Drawing.Size(62, 13);
            this.lblPengarang.TabIndex = 2;
            this.lblPengarang.Text = "Pengarang:";
            // 
            // lblTahunTerbit
            // 
            this.lblTahunTerbit.AutoSize = true;
            this.lblTahunTerbit.Location = new System.Drawing.Point(24, 89);
            this.lblTahunTerbit.Name = "lblTahunTerbit";
            this.lblTahunTerbit.Size = new System.Drawing.Size(71, 13);
            this.lblTahunTerbit.TabIndex = 3;
            this.lblTahunTerbit.Text = "Tahun Terbit:";
            // 
            // lblPenerbit
            // 
            this.lblPenerbit.AutoSize = true;
            this.lblPenerbit.Location = new System.Drawing.Point(24, 122);
            this.lblPenerbit.Name = "lblPenerbit";
            this.lblPenerbit.Size = new System.Drawing.Size(49, 13);
            this.lblPenerbit.TabIndex = 4;
            this.lblPenerbit.Text = "Penerbit:";
            // 
            // txtJudul
            // 
            this.txtJudul.Location = new System.Drawing.Point(103, 18);
            this.txtJudul.Name = "txtJudul";
            this.txtJudul.Size = new System.Drawing.Size(310, 20);
            this.txtJudul.TabIndex = 5;
            // 
            // txtPengarang
            // 
            this.txtPengarang.Location = new System.Drawing.Point(103, 55);
            this.txtPengarang.Name = "txtPengarang";
            this.txtPengarang.Size = new System.Drawing.Size(310, 20);
            this.txtPengarang.TabIndex = 6;
            // 
            // txtTahunTerbit
            // 
            this.txtTahunTerbit.Location = new System.Drawing.Point(103, 89);
            this.txtTahunTerbit.Name = "txtTahunTerbit";
            this.txtTahunTerbit.Size = new System.Drawing.Size(310, 20);
            this.txtTahunTerbit.TabIndex = 7;
            // 
            // txtPenerbit
            // 
            this.txtPenerbit.Location = new System.Drawing.Point(103, 122);
            this.txtPenerbit.Name = "txtPenerbit";
            this.txtPenerbit.Size = new System.Drawing.Size(310, 20);
            this.txtPenerbit.TabIndex = 8;
            // 
            // btnTambahBuku
            // 
            this.btnTambahBuku.Location = new System.Drawing.Point(313, 160);
            this.btnTambahBuku.Name = "btnTambahBuku";
            this.btnTambahBuku.Size = new System.Drawing.Size(100, 23);
            this.btnTambahBuku.TabIndex = 9;
            this.btnTambahBuku.Text = "Tambah Buku";
            this.btnTambahBuku.UseVisualStyleBackColor = true;
            this.btnTambahBuku.Click += new System.EventHandler(this.btnTambahBuku_Click);
            // 
            // FormUtama
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(435, 387);
            this.Controls.Add(this.btnTambahBuku);
            this.Controls.Add(this.txtPenerbit);
            this.Controls.Add(this.txtTahunTerbit);
            this.Controls.Add(this.txtPengarang);
            this.Controls.Add(this.txtJudul);
            this.Controls.Add(this.lblPenerbit);
            this.Controls.Add(this.lblTahunTerbit);
            this.Controls.Add(this.lblPengarang);
            this.Controls.Add(this.lblJudul);
            this.Controls.Add(this.dataGridViewBuku);
            this.Name = "FormUtama";
            this.Text = "Aplikasi Perpustakaan";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewBuku)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridViewBuku;
        private System.Windows.Forms.Label lblJudul;
        private System.Windows.Forms.Label lblPengarang;
        private System.Windows.Forms.Label lblTahunTerbit;
        private System.Windows.Forms.Label lblPenerbit;
        private System.Windows.Forms.TextBox txtJudul;
        private System.Windows.Forms.TextBox txtPengarang;
        private System.Windows.Forms.TextBox txtTahunTerbit;
        private System.Windows.Forms.TextBox txtPenerbit;
        private System.Windows.Forms.Button btnTambahBuku;
    }
}
