﻿public class Buku
{
    public string Id { get; set; }
    public string Judul { get; set; }
    public string Pengarang { get; set; }
    public int TahunTerbit { get; set; }
    public string Penerbit { get; set; }
}
