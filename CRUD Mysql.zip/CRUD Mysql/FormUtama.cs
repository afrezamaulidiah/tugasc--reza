﻿using System;
using System.Windows.Forms;

namespace AplikasiPerpustakaan
{
    public partial class FormUtama : Form
    {
        public FormUtama()
        {
            InitializeComponent();
            TampilkanData();
        }

        private void TampilkanData()
        {
            dataGridViewBuku.DataSource = DbPerpustakaan.TampilkanDataBuku();
        }

        private void btnTambahBuku_Click(object sender, EventArgs e)
        {
            // Mengambil data dari kontrol input
            Buku bukuBaru = new Buku
            {
                Judul = txtJudul.Text,
                Pengarang = txtPengarang.Text,
                TahunTerbit = Convert.ToInt32(txtTahunTerbit.Text),
                Penerbit = txtPenerbit.Text
            };

            // Menambahkan buku baru ke database
            DbPerpustakaan.TambahBuku(bukuBaru);

            // Menampilkan ulang data buku setelah penambahan
            TampilkanData();

            // Membersihkan input setelah penambahan
            BersihkanInput();
        }

        private void BersihkanInput()
        {
            // Membersihkan kontrol input setelah penambahan
            txtJudul.Text = string.Empty;
            txtPengarang.Text = string.Empty;
            txtTahunTerbit.Text = string.Empty;
            txtPenerbit.Text = string.Empty;
        }
    }
}
